---
name: excel-fab-assistente
description: Plugin com Excel/arquivos e concursos da FAB. Use ao receber planilha, CSV, PDF, edital, lista de inaptos, ou pedido de reclassificação, cotas, EPCAR, AFA, EEAR, CIAAR, vaga ou notícia da Aeronáutica.
metadata:
  type: plugin
  version: "1.25.0"
  plugin: excel-fab-assistente
---

# Excel + FAB Assistente

Plugin de nível superior. Carregue o componente certo e execute sem enrolação.

> **ORDEM OBRIGATÓRIA DAS LISTAS (v1.26.0)**
> Sempre gere estas quatro, nesta ordem, no Excel e no PDF:
> 1. Classificação geral — `Classificacao_Geral`
> 2. Lista só dos cotistas — `Reserva_PP`
> 3. Cotistas nas vagas da ampla — `Cotistas_Ampla`
> 4. Excluídos acumulativos — `Excluidos`, separados por etapa e, em cada etapa, ausente → incapaz → excluído, pela Clas. Original
> Estilo da 1.25.0. Não pule a 3 nem a 4. `Regras` fica por último no Excel.
>
> **AMPLA REMANESCENTE — cotista dentro da janela não gasta reserva.** Se sobram vagas de cota, elas abrem ampla depois de N. Ex.: 26 PP e só 17 cotistas fora das 104 → 9 vão para a ampla, janela 105–113. Cotista com Nova Clas. dentro dessa janela fica em vaga de ampla, Clas. RV vazia. A vaga reservada vai para cotista fora da janela. Recalcule até estabilizar. Proibido `Vaga Reservada PP` para quem está nessa ampla nova.



> **BLOQUEIO DE ENTREGA (v1.25.0) — reversão e numeração**
> Cotista com Situação da Vaga contendo `reversão` (`Vaga PP por reversão`, indígenas, quilombolas):
> - Classificação geral (aba `Classificacao_Geral` e bloco geral do PDF): linha inteira **verde** `#E2EFDA`. Proibido laranja/amarelo `#FFF2CC`.
> - Lista exclusiva dos cotistas (aba `Reserva_PP` e bloco Reserva PP): a mesma pessoa fica **laranja** `#FFF2CC`. Proibido verde nessa lista.
> - Numeração da reversão **não reinicia**. 38 PP + 8 de outras etnias = 46. Texto: `Vaga PP por reversão (39/46)`, `(40/46)`… Proibido `(1/8)`.
> - Na lista dos cotistas, `Cadastro de reserva (RV)`: ímpar/par pela **Clas. RV** (branco/cinza), não pela Nova Clas.
> Se a geral sair laranja, ou a reversão sair `(1/8)`, não entregue. Refaça e reentregue Excel e PDF.

## Componentes declarados

| Tipo | Caminho | Quando usar |
| --- | --- | --- |
| Manifesto | `.claude-plugin/plugin.json` | Identidade, versão e descoberta do plugin |
| Skill | `skills/excel-arquivos/SKILL.md` | Arquivo enviado ou pedido de planilha |
| Referência Excel | `skills/excel-arquivos/references/fluxo-arquivos.md` | Inspeção e entrega |
| Skill | `skills/fab-concursos/SKILL.md` | Concurso, edital, TAF, notícia da FAB |
| Referência FAB | `skills/fab-concursos/references/mapa-ingresso.md` | Caminhos oficiais de ingresso |
| Referência | `skills/fab-concursos/references/reclassificacao-edital.md` | Tirar inaptos, nova ordem e cotas |
| Referência | `skills/fab-concursos/references/etapas-eliminatorias.md` | Distingue INSPSAU, EAP, TACF e os recursos |
| Referência | `skills/fab-concursos/references/formato-proibido.md` | Proíbe Consolidado / Base_Geral / dashboard |
| Referência | `skills/fab-concursos/references/decisao-judicial.md` | Algoritmo: judicial = só `*`; ordinários numerados |
| Referência | `skills/fab-concursos/references/estilo-pdf-classificacao.md` | Laranja `#FFF2CC` na ampla; verde `#E2EFDA` na cota e, só na classificação geral, na reversão; cadastro RV ímpar branco e par cinza na geral E na lista dos cotistas; vermelho claro nos ausentes; sem riscado |
| Comando | `commands/excel.md` | `/excel` |
| Comando | `commands/fab.md` | `/fab` |
| Comando | `commands/listas.md` | `/listas` — sempre gera geral, só cotistas, cotistas na ampla e excluídos acumulados, nesta ordem |
| Comando | `commands/reclassificar.md` | `/reclassificar` — mesma ordem de listas; conserta cor e reentrega Excel e PDF |
| Leia-me | `README.md` | Instalação |

## Roteamento

1. Anexo ou pedido de planilha → `skills/excel-arquivos/SKILL.md`.
2. FAB, EPCAR, AFA, EEAR, CIAAR, concurso → `skills/fab-concursos/SKILL.md`.
3. Planilha + edital juntos → Excel primeiro, regra oficial depois.
4. Nova classificação / tirar inaptos / cotas / PDF de ranking → leia `reclassificacao-edital.md`, `estilo-pdf-classificacao.md` e `etapas-eliminatorias.md`. Identifique a **etapa e o ano/edital** pelo título e cabeçalho do PDF oficial antes de tirar alguém.
5. Pedido parecido com "monte um Excel e depois transforme em PDF", "quero as duas formas" ou qualquer classificação/lista → entregue os dois arquivos. Monte o Excel primeiro e transforme esse mesmo conteúdo no PDF.
6. Não invente data, vaga, soldo ou desempate. O número de vagas (N ampla, M PP) e o ano vêm **só** dos documentos enviados pelo usuário.
7. **Fonte de dados:** N, M e o ano vêm dos anexos. Não misture edital de outro ano. Exceção: na classificação, pesquise no ano do concurso quais candidatos entraram por decisão judicial e fizeram etapas por causa dela. Aplique a esses a regra de `decisao-judicial.md`. Não use a busca para inventar vaga ou nota.
8. Não risque `Cadastro de reserva (AC)` nem `Cadastro de reserva (RV)`. Continue a Clas. RV de todo cotista fora da ampla, inclusive quem ficou só no cadastro. A zebra do cadastro **não é só da classificação geral**. `Cadastro de reserva (AC)` usa a Nova Clas. numérica (ímpar branco `#FFFFFF`, par cinza `#F2F2F2`) na classificação geral. `Cadastro de reserva (RV)` usa zebra na classificação geral pela Nova Clas. e, na lista dos cotistas, pela Clas. RV (classificação na lista de cotas): ímpar branco `#FFFFFF`, par cinza `#F2F2F2`. Não use a Nova Clas. para pintar a lista dos cotistas. Não deixe esse RV laranja, verde nem de cor única. Ausentes e incapazes ficam em vermelho claro `#F6C9C9`, com letra preta. Cores oficiais: ampla `#FFF2CC`; reserva PP `#E2EFDA`; reversão verde `#E2EFDA` **somente** na classificação geral (na lista dos cotistas, reversão continua `#FFF2CC`). O estilo já está neste plugin: não peça de novo o PDF de modelo.
9. **Acúmulo de fora da ordem:** a aba `Excluidos` mantém ausentes, incapazes e excluídos de todas as etapas. Ordem dos blocos: Provas Escritas, C.I., INSPSAU, EAP, TACF. Recurso de uma etapa vem logo depois da etapa normal. Dentro de cada bloco: ausente, depois incapaz, depois excluído. Dentro de cada grupo, Clas. Original crescente. Nunca descarte o histórico.
10. Preserve colunas extras presentes nos PDFs de origem (Situação INSPSAU, Situação TACF, Observação, decisão judicial etc.).

11. **Coluna de situação:** cabeçalho completo da etapa (`Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF`). Ver `colunas-situacao-etapa.md`. **Cabeçalhos da tabela sempre centralizados** (incluindo Nome).
12. **Decisão judicial:** pesquise o ano do concurso e marque quem entrou e seguiu nas etapas por decisão judicial. Depois execute `skills/fab-concursos/references/decisao-judicial.md`. Nova Clas. judicial = só `*`. Ordinários 1,2,3… Ex.: Ana=23, Bernardo=*, Carlos=24. Teste de sanidade: se falhar, não entregue.
13. **Layout:** proibido quebrar data. Máx. 2 linhas/célula.
14. **Não entregue** com judicial numerado, `28*`, “dec. judicial” na Situação, ou data partida.
15. **Formato:** reclassificação = só tabela do plugin. Proibido Resultado Consolidado, Base_Geral e painel de totais como produto principal (`formato-proibido.md`).
19. **Quatro listas, sempre, nesta ordem:** classificação geral; lista só dos cotistas; cotistas nas vagas da ampla; excluídos (ausentes, incapazes e excluídos) acumulativo. Excel: `Classificacao_Geral`, `Reserva_PP`, `Cotistas_Ampla`, `Excluidos`, `Regras`. PDF na mesma ordem. Comando: `commands/listas.md`. Não pule a lista dos cotistas na ampla nem os excluídos.
20. **Ampla remanescente:** cotista dentro da janela aberta pela sobra (ex.: 105–113) não conta para a reserva. Clas. RV vazia. A vaga de cota fica para quem está fora dessa ampla nova. Recalcule.
21. **Ordem dos excluídos:** separe por etapa (Provas Escritas → C.I. → INSPSAU → EAP → TACF; recurso logo após a etapa). Em cada etapa, ausente, incapaz, excluído. Em cada grupo, Clas. Original crescente.
22. **PHC:** se pedirem retificação pelo Processo de Heteroidentificação Complementar, candidato não considerado PP passa a cota `Ampla Concorrência` e sai da reserva. Considerado PP mantém `Pretos e Pardos`. Não invente o resultado: use só o que o usuário ou o anexo marcar. Recalcule a classificação.
23. **Etapa real da eliminação:** a ordem em que as listas foram pedidas não congela um ausente falso. EAP pode ter ocorrido antes do recurso da INSPSAU, e mesmo assim a reclassificação do EAP vem depois dessa lista. Se a lista do EAP diz Inapto, o bloco é `EAP — Incapazes`, não `INSPSAU (recurso) — Ausentes`. Ausente do EAP que só apareceu como ausente da INSPSAU porque a INSPSAU foi atualizada antes também vai para `EAP — Ausentes`. Uma linha só, na etapa real.
24. **Busca judicial:** é permitido pesquisar, no ano do concurso, candidatos com decisão judicial que fizeram as etapas por causa dela. Cruze nome e inscrição com a lista. Aplique o algoritmo do `*`. Não marque quem a busca não confirmar.
16. **Reversão — bloqueio:** na classificação geral, toda linha com `reversão` é verde `#E2EFDA` (linha inteira). Laranja `#FFF2CC` na reversão só na lista exclusiva dos cotistas. Se a geral estiver laranja, refaça e reentregue Excel e PDF. Não encerre só atualizando a regra.
17. **Zebra do cadastro na lista dos cotistas:** o alvo é `Cadastro de reserva (RV)`, não AC. Na `Reserva_PP` e no bloco de cotistas, a paridade é a da Clas. RV: ímpar branco `#FFFFFF`, par cinza `#F2F2F2`. Proibido usar a Nova Clas. nessa lista. Clas. RV 47 branca; 48 cinza.
18. **Numeração da reversão:** não reinicia em `(1/8)`. Continua a reserva. 38 PP + 8 revertidas = `Vaga PP por reversão (39/46)`, `(40/46)`… `(46/46)`. Se sair `(1/8)`, refaça e reentregue Excel e PDF.
