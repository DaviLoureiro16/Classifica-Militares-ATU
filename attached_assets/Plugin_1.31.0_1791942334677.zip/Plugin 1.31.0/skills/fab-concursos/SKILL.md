---
name: fab-concursos
description: Orienta concursos e notícias da FAB e executa reclassificação. Use para EPCAR, AFA, EEAR, edital, cotas, inaptos, nova classificação, TAF, inspeção de saúde ou estatística da Aeronáutica.
---

# Concursos e notícias da FAB

Não invente prazo, vaga ou soldo.

> **BLOQUEIO — reversão (v1.25.0)**
> Se Situação da Vaga contém `reversão`:
> - classificação geral → verde `#E2EFDA` na linha inteira. Nunca laranja.
> - lista exclusiva dos cotistas → laranja `#FFF2CC` na linha inteira. Nunca verde.
> - texto da reversão não reinicia: `Vaga PP por reversão (39/46)`, não `(1/8)`.
> - na lista dos cotistas, cadastro RV: cor pela Clas. RV (ímpar branco, par cinza).
> Entregar a geral com reversão laranja, ou reversão `(1/8)`, é falha.


## Fonte de dados e identificação do edital (regra crítica)

- O ano do concurso, o número de vagas de ampla (N) e de reserva PP (M) são lidos **exclusivamente** dos documentos que o usuário enviou (título do PDF, cabeçalho, linha de resumo, edital anexo).
- **Não** assuma EA CPCAR 2027 nem qualquer outro ano. Não use 104/38 ou 120/30 de memória.
- Se o usuário **já forneceu** PDFs oficiais (classificação, resultado de etapa, lista de ausentes/incapazes, edital etc.) para gerar Excel e PDF de reclassificação, use **somente** esses anexos.
- **Não** busque vaga, nota ou edital de outro ano. **Pode** pesquisar, no ano do concurso, quem entrou por decisão judicial e fez as etapas por causa dela. Aplique `decisao-judicial.md` a esses candidatos.
- Se os anexos não trouxerem o número de vagas, **pergunte** antes de fechar as cotas.

Leia `references/mapa-ingresso.md` para o mapa das escolas.

Se o pedido for reclassificar, tirar inaptos, cotas, planilha ou PDF, leia:
- `references/reclassificacao-edital.md`
- `references/estilo-pdf-classificacao.md`
- `references/etapas-eliminatorias.md`
- `references/regras-edital-classificacao.md`
- `references/colunas-situacao-etapa.md` ← colunas de etapa com cabeçalho completo (`Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF`)
- `references/formato-proibido.md` ← proíbe Resultado Consolidado / Base_Geral / dashboard
- `references/decisao-judicial.md` ← algoritmo obrigatório de numeração judicial (MF, desempate, cotas, reversão — **sem** números de vagas)

Antes de excluir, diga qual etapa e qual ano/edital o PDF representa.

No Excel e no PDF, mantenha todos os dados originais do candidato: nome, inscrição, MF, Port, Mat, Ing, Red, nascimento, cota, classificação original e as demais colunas da lista (incluindo Situação INSPSAU, Situação TACF, Observação etc., se existirem).

Entregue sempre Excel e PDF.

### Cores obrigatórias (não alterar)

- Vaga de ampla → laranja claro `#FFF2CC` (mesmo se for cotista dentro da ampla)
- Vaga de cota depois da ampla → verde claro `#E2EFDA`
- Vaga por reversão → na classificação geral, verde `#E2EFDA` obrigatório (mesmo verde da reserva). Na lista exclusiva dos cotistas, laranja `#FFF2CC` obrigatório. Não copie a cor de uma lista para a outra. Reversão laranja na geral = não entregue
- Cadastro de reserva (AC) → ímpar branco `#FFFFFF`, par cinza `#F2F2F2`, pela Nova Clas. numérica, na classificação geral
- Cadastro de reserva (RV) → zebra na geral pela Nova Clas.; na lista dos cotistas pela Clas. RV (ímpar branco `#FFFFFF`, par cinza `#F2F2F2`). Não use a Nova Clas. para colorir a lista de cotas. Alvo é RV, não AC
- Ausentes e incapazes → vermelho claro `#F6C9C9`, letra preta
- Cabeçalho da tabela → `#1F3864`
- Sem tachado em nenhuma célula
- Cota por extenso (`Ampla Concorrência` / `Pretos e Pardos`)
- `Clas. RV` continua para todo cotista fora da ampla, inclusive no cadastro de reserva

**Decisão judicial:** pesquise o ano do concurso e identifique quem seguiu por decisão judicial. Execute `references/decisao-judicial.md`. Nova Clas. = só `*`. Ordinários 1,2,3… Ex.: Ana=23, Bernardo=*, Carlos=24. Se o teste de sanidade falhar, não entregue.

**Layout (não erre):** proibido quebrar data ou cortar texto. Máx. 2 linhas/célula. Se apertar, corte colunas de situação, não o texto.

**Coluna de situação:** cabeçalho completo da etapa atual (`Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF`). Ver `colunas-situacao-etapa.md`.

**Acúmulo obrigatório:** a aba Ausentes é cumulativa entre C.I., INSPSAU, EAP, TACF e seus recursos. Mantenha quem saiu em etapas anteriores e some os eliminados da etapa atual. Registre a etapa em que cada um saiu. Nunca apague o histórico.

## Fontes (usar só quando não houver anexo suficiente e o usuário autorizar)

- https://www.fab.mil.br/admissao/
- https://www.fab.mil.br/noticias/tag/concurso/
- https://ingresso.eear.fab.mil.br/
- https://www.fab.mil.br/admissao/militares-de-carreira/afa/
- https://www.fab.mil.br/admissao/militares-de-carreira/epcar/

## Limites

- Não ensine a furar inspeção, TAF, psicológico, cotas ou documento.
- Não prometa aprovação.
- Distinga carreira de temporário.
- Conteúdo adequado a menores.
