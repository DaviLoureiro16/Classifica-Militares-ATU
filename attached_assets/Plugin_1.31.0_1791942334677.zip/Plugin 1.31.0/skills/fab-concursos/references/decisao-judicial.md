# Decisão judicial — algoritmo obrigatório (não interprete, execute)

Esta regra **substitui qualquer outra interpretação**. Se o PDF de origem marcar candidato como mantido por liminar / decisão judicial / reintegração judicial, faça **exatamente** o abaixo.

## Busca permitida

Na classificação do ano do concurso, pesquise quais candidatos entraram por decisão judicial e fizeram as etapas em decorrência dela. Cruze nome e inscrição com a lista anexa. Quem a busca ou o anexo confirmar é judicial e recebe esta regra. Não marque candidato sem confirmação. A busca não serve para mudar N, M ou nota.


## Definição

Candidato **judicial** = permanece no concurso por força de decisão judicial (texto no PDF: “decisão judicial”, “liminar”, “reintegrado”, “Apto (judicial)”, asterisco no nome, etc.).

Candidato **ordinário** = todos os outros.

## Algoritmo de numeração (passo a passo)

```
lista = candidatos presentes ordenados por MF desc (desempate do edital)
numero = 1
para cada candidato em lista:
    se candidato é judicial:
        Nova_Clas = "*"          # string com um único caractere asterisco
        Observacao = "Decisão judicial"
        # NÃO incremente numero
    senão:
        Nova_Clas = str(numero)  # "1", "2", "3", ...
        numero = numero + 1
```

### Resultado obrigatório (exemplo)

| Ordem por MF | Nome     | Tipo      | Nova Clas. | Observação        |
|--------------|----------|-----------|------------|-------------------|
| 1º           | Ana      | ordinário | `23`       | (vazio)           |
| 2º           | Bernardo | judicial  | `*`        | Decisão judicial  |
| 3º           | Carlos   | ordinário | `24`       | (vazio)           |

**Errado (proibido):**
- `28*` 
- `28 (*)`
- `28` com Observação “Decisão judicial (*)”
- `28` com Situação “Ausente - dec. judicial”
- pular o número (Ana=23, Bernardo=*, Carlos=25) ← Carlos deve ser 24

## Colunas — o que pode e o que não pode

| Coluna              | Judicial                         | Ordinário        |
|---------------------|----------------------------------|------------------|
| Nova Clas.          | somente `*`                      | número inteiro   |
| Situação INSPSAU/…  | `Apto` / `Ausente` / `Incapaz`   | idem             |
| Observação          | `Decisão judicial`               | vazio ou outro   |

**Proibido** escrever “judicial”, “dec. judicial”, “liminar” ou `(*)` em qualquer coluna que não seja Nova Clas. (só `*`) ou Observação (só o texto limpo).

## Expansão de vagas de ampla

```
N = vagas de ampla lidas do edital/PDF
ordinarios_na_faixa = primeiros N candidatos ordinários (já numerados 1..N)
judiciais_na_faixa = judiciais cuja MF está entre a do 1º e a do N-ésimo ordinário
bloco_ampla = ordinarios_na_faixa + judiciais_na_faixa
# todos no bloco_ampla recebem Situação da Vaga = "Vaga Ampla (1-N)"
# tamanho do bloco = N + K, onde K = len(judiciais_na_faixa)
```

Rodapé / aba Regras (texto obrigatório se K > 0):
`K candidatos por decisão judicial (Nova Clas. = *) na faixa de ampla → bloco com N+K pessoas.`

## Teste de sanidade (falhou = refazer antes de entregar)

1. Existe alguma Nova Clas. que contenha dígito **e** `*` juntos? → **REFAZER**
2. Existe judicial com Nova Clas. numérica? → **REFAZER**
3. A sequência numérica dos ordinários tem buraco (1,2,4…)? → **REFAZER** (buraco só seria aceitável se faltasse candidato, nunca por causa de judicial)
4. A palavra “judicial” aparece na coluna de Situação da etapa? → **REFAZER**
5. Alguma data está partida (`25/05/200` + linha com `9`)? → **REFAZER**

Se qualquer item falhar, **não entregue** o PDF/Excel. Corrija e só então entregue.
