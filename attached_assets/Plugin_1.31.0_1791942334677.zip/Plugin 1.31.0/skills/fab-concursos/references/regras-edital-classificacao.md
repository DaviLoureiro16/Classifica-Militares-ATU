# Regras de classificação e cotas (extraídas do edital)

Fonte: IE EA CPCAR (estrutura comum). **Não use números de vagas daqui** — N (ampla) e M (PP/indígenas/quilombolas) vêm sempre dos PDFs ou do edital que o usuário enviou.

## Média Final (MF) e aproveitamento

- MF = (GP + GM + GI + GR) / 4
  - GP = Língua Portuguesa
  - GM = Matemática
  - GI = Língua Inglesa
  - GR = Redação
- Grau mínimo em **cada** prova escrita (incluindo Redação): 5,0000
- Grau mínimo da MF: 5,0000
- Candidatos com aproveitamento são ordenados por MF **decrescente**

## Média Parcial (MP) — usada na classificação parcial (antes da Redação)

- MP = (GP + GM + GI) / 3
- Grau mínimo em cada disciplina: 5,0000

## Critérios de desempate

### Empate na MF (ordem de precedência)
1. Maior grau em Língua Portuguesa (GP)
2. Maior grau em Matemática (GM)
3. Maior grau em Língua Inglesa (GI)
4. Maior grau em Redação (GR)
5. Maior idade (data de nascimento mais antiga)

### Empate na MP (ordem de precedência)
1. Maior grau em Língua Portuguesa (GP)
2. Maior grau em Matemática (GM)
3. Maior grau em Língua Inglesa (GI)
4. Maior idade

**Na prática da reclassificação pós-etapas:** se MF empatar e as notas individuais não resolverem, use a classificação original menor como desempate auxiliar (já reflete a ordem oficial anterior).

## Reserva de vagas (regras, sem quantidades)

- Reserva de 30% do total de vagas, na forma da Lei nº 15.142/2025:
  - 25% pretos e pardos
  - 3% indígenas
  - 2% quilombolas
- A reserva só se aplica quando o número de vagas por especialidade for ≥ 2.
- Fracionamento: fração ≥ 0,5 → arredonda para cima; fração < 0,5 → arredonda para baixo.

### Concorrência concomitante (Art. 28)
- Cotistas (PP, indígenas, quilombolas) optantes pela reserva **concorrem ao mesmo tempo** às vagas reservadas **e** às de ampla concorrência, conforme sua classificação.
- **Parágrafo único:** cotista classificado **dentro do número de vagas de ampla** não é computado no preenchimento das vagas reservadas.

### Reversão de vagas não preenchidas
1. Quilombolas sem candidatos suficientes → reverte para indígenas
2. Indígenas sem candidatos suficientes → reverte para quilombolas
3. Indígenas **ou** quilombolas sem candidatos → reverte para pretos e pardos, e por último para ampla concorrência
4. Ampla sem candidatos suficientes → reverte para PP / indígenas / quilombolas, observada a proporcionalidade
5. Se não houver cotistas aprovados em número suficiente para as reservadas → remanescentes revertem para ampla concorrência (ordem de classificação)

### Desistência / exclusão em vaga reservada
- A vaga é preenchida pelo próximo classificado que optou pela reserva (mesma modalidade).

### Autodeclaração e verificação
- Pretos e pardos: Procedimento de Confirmação da Autodeclaração (PCCA)
- Indígenas e quilombolas: Procedimento de Verificação Documental Complementar (PVDoc)
- Todos os optantes pela reserva devem se submeter ao PCCA/PVDoc, mesmo se já tiverem nota para ampla.
- Autodeclaração não confirmada → concorre só à ampla (salvo má-fé, que elimina).
- Não se submeter ao PCCA quando convocado → exclusão.
- Declaração falsa → eliminação (e anulação de matrícula se já matriculado), com contraditório e ampla defesa.

### Múltiplas reservas
- Candidato que optar por mais de uma modalidade de reserva é classificado **somente** na modalidade de percentual mais elevado, observada a ordem de classificação.

## Resultado final e habilitação à matrícula

Candidato em condições de ser apreciado para habilitação à matrícula se:
1. COM APROVEITAMENTO nas Provas Escritas (MF ≥ 5,0000 e cada prova ≥ 5,0000)
2. APTO na INSPSAU, no EAP e no TACF
3. Confirmação da autodeclaração no PCCA ou PVDoc (somente se estiver dentro das vagas reservadas)
4. Não tiver sido excluído em etapa anterior

Convocação: ordem decrescente de MF + critérios de desempate + relação nominal dos aprovados.

Excedentes: aprovados em todas as etapas mas fora do número de vagas; convocáveis até a validade do exame, na ordem de classificação da modalidade a que concorrem.

## Aplicação na reclassificação (plugin)

1. Ordene presentes por MF decrescente; empate → critérios acima (ou Clas. Original menor se as notas individuais não estiverem disponíveis).
2. Preencha as primeiras N posições com `Vaga Ampla (1-N)` (N dos anexos).
3. Cotista dentro de N → ocupa ampla, **não gasta** reserva, `Clas. RV` vazia (Art. 28, parágrafo único).
3.1. Se a reserva não enche, a sobra abre uma ampla remanescente depois de N. Ex.: 26 PP e 17 cotistas fora das 104 → janela 105–113. Cotista cuja Nova Clas. cai nessa janela também ocupa ampla, **não gasta** reserva e não entra na lista só dos cotistas. A vaga reservada que ele pegaria vai para o cotista seguinte, fora da janela. Se isso aumentar a sobra, a janela cresce e o cálculo recomeça até estabilizar. Proibido `Vaga Reservada PP` dentro da ampla nova.
4. Depois de N, cotistas restantes preenchem as vagas reservadas (`Vaga Reservada PP (n/M)`, e equivalentes para indígenas/quilombolas se houver candidatos e vagas).
5. Aplique reversões na ordem do edital quando uma modalidade não tiver candidatos. Texto não reinicia: 38 PP + 8 revertidas = `Vaga PP por reversão (39/46)` … `(46/46)`, não `(1/8)`. Cor: verde `#E2EFDA` na classificação geral; laranja `#FFF2CC` só na lista exclusiva dos cotistas.
6. Restante → Cadastro de reserva (AC ou RV). Na geral, zebra pela Nova Clas. Na lista dos cotistas, `Cadastro de reserva (RV)` usa a Clas. RV: ímpar `#FFFFFF`, par `#F2F2F2`. Não use a Nova Clas. nessa lista.
7. Continue a numeração `Clas. RV` de todos os cotistas fora da ampla, inclusive no cadastro de reserva.


## Decisão judicial e expansão de vagas (OBRIGATÓRIO)

**Execute o algoritmo completo em `decisao-judicial.md`.** Resumo:

- Nova Clas. do judicial = **somente** `*` (sem número algum).
- Exemplo de sequência correta:
  - Ana → `23`
  - Bernardo (judicial) → `*`
  - Carlos → `24`
- Observação = `Decisão judicial`. Não misturar “judicial” na coluna de Situação da etapa.
- Sem prioridade: ordem = MF + desempate.
- Numeração 1,2,3… **apenas** para não-judiciais.
- Expansão: números 1…N só para não-judiciais; K judiciais na faixa de MF recebem `Vaga Ampla` também → bloco com N+K pessoas.
- Antes de entregar, conferir: nenhum judicial numerado; numeração contínua; datas sem quebra.



## PHC — Processo de Heteroidentificação Complementar

Se o usuário pedir retificação da classificação por causa do PHC:
- candidato considerado não PP: cota passa a `Ampla Concorrência`; não ocupa vaga reservada; Clas. RV vazia;
- candidato considerado PP: cota permanece `Pretos e Pardos`.
Use somente o resultado informado pelo usuário ou pelo anexo. Depois recalcule a classificação.
