# Etapas eliminatórias da EPCAR

Base: os PDFs oficiais de resultado e o edital do ano correspondente que o usuário fornecer. INSPSAU, EAP e TACF são eliminatórios. Só entra na classificação de uma etapa quem ficou apto nela, já aplicado o recurso se ele tiver sido enviado.

## Como reconhecer o PDF e o ano

Leia o **título e o cabeçalho** do PDF. O ano (2025, 2026, 2027…) e o número de vagas vêm dali — nunca de memória ou de outro concurso.

| Título no PDF | Etapa | Colunas típicas | Situação que permanece | Situação que sai |
| --- | --- | --- | --- | --- |
| Resultado da Inspeção de Saúde | Pós-INSPSAU | Inscrição, Nome, Situação | Apto | Incapaz, Ausente |
| Resultado da Inspeção de Saúde em Grau de Recurso | Pós-INSPSAU em recurso | Inscrição, Nome, Situação | Apto | Incapaz, Ausente |
| Aptidão Psicológica / Exame de Aptidão Psicológica | Pós-EAP | Inscrição, Nome, Especialidade, Situação ou Parecer | Apto | Incapaz, Ausente |
| Exame de Aptidão Psicológica em grau de recurso | Pós-EAP em recurso | Inscrição, Nome, Especialidade, Parecer | Apto | Incapaz, Ausente |
| Resultado do Teste de Avaliação do Condicionamento Físico | Pós-TACF | Inscrição, Nome, Situação | Apto | Incapaz, Ausente |
| Resultado do TACF em Grau de Recurso | Pós-TACF em recurso | Inscrição, Nome, Situação | Apto | Incapaz, Ausente |
| Classificação … após a Concentração Intermediária / C.I. | Pós-C.I. | Classificação completa | Presente | Ausente |

Asterisco no nome significa decisão judicial. Mantenha a nota. Não exclua só por causa do asterisco.

## Ordem das etapas

1. Provas escritas e concentração intermediária (C.I.).
2. INSPSAU. Quem não fica apto não segue.
3. Recurso da INSPSAU substitui o parecer só de quem está nessa lista.
4. EAP, em paralelo com a saúde no calendário, mas também eliminatório.
5. Recurso do EAP substitui o parecer só de quem está nessa lista.
6. TACF só para quem está apto para matrícula na INSPSAU.
7. Recurso do TACF substitui o parecer só de quem está nessa lista.

## Como cruzar

1. Identifique cada anexo pelo título e diga qual etapa é, **e qual o ano/edital**, antes de calcular.
2. Extraia N (vagas ampla) e M (vagas PP) do próprio material enviado. Não use valores de outro ano.
3. Se houver lista inicial e lista de recurso da mesma etapa, o recurso prevalece para quem aparece nele. Quem não aparece no recurso fica com o resultado da lista inicial.
4. Apto no recurso volta à classificação. Incapaz, inapto, não apto ou ausente no recurso continua fora.
5. Tire da ordem quem saiu na etapa atual. Reordene os que ficaram por MF decrescente. Empate: classificação original menor na frente.
6. Recalcule ampla, reserva e reversão com os números do edital/PDFs fornecidos, nas cores já definidas.
7. No título do PDF e na aba Regras, escreva a etapa e o ano: por exemplo "EA CPCAR 2026 — Classificação pós-TACF".
8. Não misture inapto de EAP com incapaz de INSPSAU. Cada parecer vale só para a etapa do arquivo.

## Acúmulo de ausentes, excluídos e incapazes (obrigatório)

Mesmo após as atualizações de etapa (C.I., INSPSAU, EAP, TACF e seus recursos), a aba **Ausentes** deve manter **todos** os candidatos que saíram em qualquer momento do processo.

- Carregue o histórico de fora da ordem da classificação anterior (ou das listas oficiais de ausentes/incapazes já publicadas).
- Some os novos eliminados da etapa que está sendo processada.
- Não apague, não substitua e não filtre o histórico. Quem saiu em C.I. continua na lista quando chegar a INSPSAU; quem saiu em INSPSAU continua quando chegar a EAP/TACF, e assim por diante.
- Em cada linha registre a situação e a etapa em que o candidato saiu (ex.: `Ausente C.I.`, `Incapaz INSPSAU`, `Incapaz TACF`, `Ausente TACF`).
- Use só as palavras **Ausente** ou **Incapaz** no texto final da situação (Inapto / Não Apto → Incapaz). Excluído permanece Excluído.
- Cor da linha: vermelho claro `#F6C9C9`, letra preta.

## Etapa real, não a ordem do pedido

O EAP pode ter ocorrido antes do recurso da INSPSAU. O usuário pode pedir a reclassificação do EAP depois da lista já atualizada da INSPSAU. Essa ordem de pedido não muda a etapa em que a pessoa saiu.

Erro já cometido: Ian Porto Vasconcelos, inscrição 2060443, Clas. Original 355, consta como Inapto na lista do EAP. Foi deixado em `INSPSAU (recurso) — Ausentes` porque não estava na lista da INSPSAU. Isso está errado. Como foi inapto no EAP, o bloco é `EAP — Incapazes`. Não crie as duas linhas.

A mesma correção vale para ausente do EAP que ficou como ausente da INSPSAU só porque a atualização da INSPSAU entrou primeiro. Se a lista do EAP diz Ausente, o bloco é `EAP — Ausentes`.

Antes de entregar, cruze a lista oficial da etapa com a aba `Excluidos`. Situação da lista oficial manda: Inapto/Incapaz/Não apto → Incapaz naquela etapa; Ausente → Ausente naquela etapa.

## O que permanece na planilha e no PDF

Depois de tirar quem saiu da etapa, mantenha todas as informações originais do candidato. Não reduza a tabela a inscrição, nome e situação.

Colunas-base (nessa ordem, quando existirem):

Nova Clas., Nome, Inscrição, Clas. RV, Situação da Vaga, MF, Port, Mat, Ing, Red, Dt_nasc, Cota, Clas. Original, Clas. RV Original.

Se a lista de origem tiver outras colunas (Situação INSPSAU, Situação TACF, Observação, sexo, OCL, especialidade, parecer da etapa, nota de cada prova, decisão judicial), **conserve todas**, depois das colunas acima. O parecer da etapa entra como coluna própria, sem apagar MF, notas, cota ou data de nascimento.

## Lista de fora

Junto com ausentes e excluídos, inclua quem ficou incapaz, inapto ou não apto. No PDF e no Excel, use só a palavra Incapaz para esses três casos. Ausente continua Ausente. Não escreva Inapto nem Não Apto no arquivo entregue.

Essa lista guarda os dados originais do candidato, mais a situação e a etapa em que saiu.

O PDF gerado é organização de estudo. A lista oficial continua sendo a da EPCAR.
