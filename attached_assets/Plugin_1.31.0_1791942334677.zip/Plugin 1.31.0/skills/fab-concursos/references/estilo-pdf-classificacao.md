# Estilo da tabela (modelo oficial do plugin) — OBRIGATÓRIO

> **ATENÇÃO (v1.26.0) — NÃO IGNORE**
> 1. **Reversão na classificação geral = verde `#E2EFDA`.** Laranja `#FFF2CC` só na lista exclusiva dos cotistas. Texto da reversão continua a reserva: `(39/46)`, não `(1/8)`.
> 2. **Cabeçalhos da tabela (linha 1):** TODOS centralizados, **incluindo Nome**. Proibido left no título "Nome".
> 3. **Coluna de etapa:** use `Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF` (COMPLETO). Proibido `CI` ou `Inspeção` sozinhos.
> 4. Corpo da coluna Nome = left. Cabeçalho da coluna Nome = **center**. São regras diferentes.

## Cor da reversão — decisão por lista (obrigatória)

A mesma pessoa muda de cor conforme a lista. Não use uma cor só.

| Onde | Texto da Situação da Vaga | Fundo da linha inteira |
| --- | --- | --- |
| Classificação geral | contém `reversão` | Verde `#E2EFDA` |
| Lista exclusiva dos cotistas | contém `reversão` | Laranja `#FFF2CC` |

Antes de entregar, percorra a aba `Classificacao_Geral` e o bloco geral do PDF. Se qualquer linha com `reversão` estiver `#FFF2CC`, amarela ou sem verde, **não entregue**: pinte `#E2EFDA` e gere os dois arquivos de novo. Na `Reserva_PP`, essa mesma linha tem de estar `#FFF2CC`.



**Este estilo é o único formato de saída da reclassificação.** Não substitua por “Resultado Consolidado”, Base_Geral nem dashboard de totais (ver `formato-proibido.md`).

## Página

- A4 **paisagem**, margem ≈ 0,6–0,8 cm.
- Fonte: Calibri ou Arial.
  - Excel: 9 pt
  - PDF: 7–8 pt (mínimo 6,5 pt só se ainda legível)
- Título centralizado, azul-marinho `#1F3864`, duas linhas.
- Cabeçalho da tabela **repetido em todas as páginas**.
- 35–42 linhas de dados por página (priorize legibilidade).
- Número da página no canto inferior direito.

## Largura e espaçamento — NÃO APERTE O TEXTO

**Proibido:**
- Quebrar data no meio (`25/05/200` + `9` na linha de baixo).
- Cortar nome, inscrição ou Situação da Vaga.
- Colunas tão estreitas que forcem mais de 2 linhas por célula.

**Obrigatório:**
- Cada célula cabe em **no máximo 2 linhas**, sem cortar palavras.
- Data (`Dt_nasc`) em **uma única linha** no formato `DD/MM/AAAA`.
- Nome (corpo): coluna larga, alinhado à esquerda.
- Demais colunas do corpo: centralizadas.
- **Cabeçalhos (títulos de coluna):** todos centralizados, inclusive “Nome”.
- Padding interno ≥ 2–3 pt.
- No Excel: `autofit` com largura mínima razoável por coluna.
- No PDF: larguras fixas proporcionais que respeitem as regras acima.
- Se não couber tudo, **reduza o número de colunas de situação** (veja abaixo), nunca aperte o texto.

## Colunas de situação da etapa

**Leia** `colunas-situacao-etapa.md`.

- Cabeçalhos **completos** (não abreviados):
  - Pós-CI / CINTER → `Situação CI`
  - Pós-INSPSAU → `Situação INSPSAU`
  - Pós-EAP → `Situação EAP`
  - Pós-TACF → `Situação TACF`
- Use a coluna da etapa que está sendo processada. Se o usuário pedir histórico, pode haver mais de uma.
- Valores: `Presente`, `Ausente`, `Apto`, `Incapaz`, `Excluído`.
- Judicial **não** vai nessa coluna → vai em Observação + `*` na Nova Clas.
- Aba Ausentes continua cumulativa.

## Cabeçalho da tabela — OBRIGATÓRIO CENTRALIZAR TUDO

- Fundo `#1F3864`, texto branco, negrito.
- **TODOS os títulos de coluna centralizados** — sem exceção.
- Isso inclui explicitamente a coluna **Nome**. Nunca use `horizontal='left'` no cabeçalho de Nome.
- No Excel (openpyxl): para **todas** as células da linha 1 use `Alignment(horizontal='center', vertical='center', wrap_text=True)`.
- No PDF: force center em todos os header cells.
- Bordas `#BFBFBF`.
- Altura para caber o título da coluna sem corte (máx. 2 linhas no cabeçalho).

**Erro clássico a evitar:** gerar o cabeçalho de “Nome” alinhado à esquerda porque o corpo da coluna Nome é left. Corpo e cabeçalho são independentes.

## Corpo

- Texto sempre preto `#000000`.
- Grade `#BFBFBF`.
- **Proibido** tachado em qualquer célula.

## Colunas-base (ordem)

Nova Clas. | Nome | Inscrição | Clas. RV | Situação da Vaga | MF | Port | Mat | Ing | Red | Dt_nasc | Cota | Clas. Original | Clas. RV Original | **(uma ou mais de:** `Situação CI` **/** `Situação INSPSAU` **/** `Situação EAP` **/** `Situação TACF`**)** | Observação

**Cabeçalhos (linha 1):** TODOS centralizados — Nome, Inscrição, Clas. RV, Situação da Vaga, MF… sem exceção.
**Corpo:** Nome à esquerda; demais colunas centralizadas.

## Textos por extenso

- Cota: `Ampla Concorrência` | `Pretos e Pardos` | `Indígenas` | `Quilombolas`
- Ampla: `Vaga Ampla (1-N)`
- Reserva: `Vaga Reservada PP (n/M)` (e equivalentes)
- Reversão: `Vaga PP por reversão (39/46)` — numerador continua a reserva; denominador = PP originais + vagas revertidas. Proibido `(1/8)`.
- Fora: `Cadastro de reserva (AC)` | `Cadastro de reserva (RV)`

## Cores da linha inteira

| Situação da Vaga | Onde | Fundo | Hex |
|------------------|------|-------|-----|
| Vaga Ampla | Geral e lista de cotistas | Laranja | `#FFF2CC` |
| Vaga Reservada PP | Geral e lista de cotistas | Verde | `#E2EFDA` |
| Vaga por reversão (`Vaga PP por reversão` e equivalentes) | **Só classificação geral** | Verde | `#E2EFDA` |
| Vaga por reversão | **Lista dos cotistas** (`Reserva_PP`) | Laranja | `#FFF2CC` |
| Cadastro de reserva (AC) ímpar | Classificação geral | Branco | `#FFFFFF` |
| Cadastro de reserva (AC) par | Classificação geral | Cinza | `#F2F2F2` |
| Cadastro de reserva (RV) ímpar | Geral: Nova Clas. Lista dos cotistas: Clas. RV | Branco | `#FFFFFF` |
| Cadastro de reserva (RV) par | Geral: Nova Clas. Lista dos cotistas: Clas. RV | Cinza | `#F2F2F2` |
| Ausente / Incapaz | Qualquer lista | Vermelho claro | `#F6C9C9` |

Reversão: na classificação geral a linha inteira é verde `#E2EFDA` (igual à vaga reservada). Erro recorrente: pintar esses cotistas de laranja `#FFF2CC` na geral, como se fossem ampla. Isso invalida a entrega. Laranja na reversão existe só na lista exclusiva dos cotistas.

Cadastro: use a **Nova Clas. numérica** para ímpar/par (não a posição visual da linha e não a Clas. RV). Quem tem só `*` não entra nessa alternância (trate a linha como a cor da Situação da Vaga). Nunca verde/laranja no cadastro. Sem riscado. Cotista dentro da ampla continua laranja, não verde.

**Numeração da reversão — não reinicia.** Se o edital tem 38 PP e 8 vagas de outras etnias revertem para PP, o total da modalidade passa a 46. As 38 reservadas continuam `Vaga Reservada PP (1/38)` … `(38/38)`. As revertidas são `Vaga PP por reversão (39/46)`, `(40/46)` … `(46/46)`. O numerador é a continuação da reserva (a mesma Clas. RV da vaga). O denominador é PP originais + vagas revertidas. Proibido `(1/8)`, `(2/8)` e qualquer fração que recomece em 1 ou use só as 8 vagas revertidas no denominador.

**Zebra na lista dos cotistas — Clas. RV, não Nova Clas.** Na aba `Reserva_PP` e no bloco de cotistas, `Cadastro de reserva (RV)` usa a classificação dele na lista de cotas: Clas. RV ímpar = branco `#FFFFFF`, Clas. RV par = cinza `#F2F2F2`. Ex.: Clas. RV 47 branca; 48 cinza, mesmo que a Nova Clas. tenha outra paridade. Na classificação geral, a zebra do cadastro continua pela Nova Clas. Vaga reservada e reversão não entram nessa zebra.

## Decisão judicial

**Leia e execute** `references/decisao-judicial.md` (algoritmo completo).

Resumo inegociável:
- Nova Clas. do judicial = **somente** o caractere `*` (sem dígitos).
- Ordinários: 1, 2, 3… sem buraco causado por judicial.
- Ex.: Ana=`23`, Bernardo=`*`, Carlos=`24`.
- Observação = `Decisão judicial`. Situação da etapa **sem** a palavra judicial.
- Bloco ampla = N ordinários numerados + K judiciais com `*`.
- Teste de sanidade em `decisao-judicial.md`: se falhar, **não entregue**.


## Clas. RV — regra crítica

- **Cotista com Situação da Vaga = Vaga Ampla** → Clas. RV **obrigatoriamente vazia** (célula em branco). Não gasta reserva.
- Cotista fora da ampla (Reservada PP, reversão ou Cadastro RV) → Clas. RV contínua a partir de 1.
- **Teste de sanidade:** se existir linha com "Vaga Ampla" E Clas. RV preenchida → **REFAZER**.

## Excluídos acumulativos

- Aba `Excluidos` e quarto bloco do PDF. Sempre presente.
- Inclui ausentes, incapazes e excluídos. Situação: `Ausente`, `Incapaz` ou `Excluído`.
- Fundo `#F6C9C9`, letra preta. Motivo e etapa em Observação (`Ausente C.I.`, `Incapaz TACF`, `Excluído nas provas escritas`).
- Lista **cumulativa**. Nunca substitua o histórico.
- Ordem: etapa, e dentro da etapa o tipo, e dentro do tipo a Clas. Original.
- Etapas, nesta ordem: Provas Escritas, C.I., INSPSAU, EAP, TACF. Recurso de uma etapa entra imediatamente depois da etapa normal.
- Em cada etapa: ausentes, depois incapazes, depois excluídos.
- Em cada grupo: classificação original crescente.
- Não entregue a aba `Excluidos` em ordem alfabética nem só pela Clas. Original global.
- A etapa do bloco é a da lista oficial em que a pessoa saiu. Inapto no EAP não fica em `INSPSAU (recurso) — Ausentes` só porque a INSPSAU foi atualizada antes. Ex.: Ian Porto Vasconcelos, 2060443, Clas. Original 355 → `EAP — Incapazes`.

## Quatro listas — ordem obrigatória

Excel e PDF sempre trazem estas quatro, nesta ordem. A terceira não é opcional.

1. Classificação geral — aba `Classificacao_Geral`. Ampla, cotistas na ampla, reserva, reversão e cadastros. Reversão verde `#E2EFDA`.
2. Lista só dos cotistas — aba `Reserva_PP`. Fora da ampla. Reversão laranja `#FFF2CC`. Cadastro RV pela Clas. RV.
3. Cotistas nas vagas da ampla — aba `Cotistas_Ampla`. Cotista em vaga de ampla, inclusive na janela remanescente. Linha laranja `#FFF2CC`. Clas. RV vazia. Não gasta reserva.
4. Excluídos acumulativos — aba `Excluidos`. Ausentes, incapazes e excluídos de todas as etapas. Fundo `#F6C9C9`. Não apague quem saiu antes.

`Regras` fica por último no Excel. Não misture excluídos na geral.
