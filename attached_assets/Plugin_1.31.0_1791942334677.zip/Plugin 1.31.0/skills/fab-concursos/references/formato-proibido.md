# Formato proibido vs formato obrigatório

## Quando o usuário pede reclassificação / nova classificação / ranking / PDF de classificação EPCAR

### PROIBIDO entregar
- Documento intitulado “Resultado Consolidado”
- Painel/dashboard com células de parâmetros (vagas editáveis, totais INSPSAU, totais TACF) como produto principal
- “Base_Geral” com classificados e eliminados misturados na ordem das provas escritas
- Exportação LibreOffice/openpyxl de planilha de consolidado estatístico no lugar da tabela
- Qualquer relatório que substitua a tabela de classificação colorida do plugin

### OBRIGATÓRIO entregar
- **Excel, nesta ordem:** `Classificacao_Geral` | `Reserva_PP` | `Cotistas_Ampla` | `Excluidos` | `Regras`
- **PDF, mesma ordem:** classificação geral; lista só dos cotistas; cotistas nas vagas da ampla; excluídos (ausentes, incapazes e excluídos) acumulativo
- **PDF:** paisagem, estilo `estilo-pdf-classificacao.md`, numeração `decisao-judicial.md`
- Título do tipo: `EA CPCAR AAAA — Classificação pós-XXXX`
- Uma linha de resumo no topo (presentes · fora da ordem · N ampla · M PP) — **não** um quadro de parâmetros

### Se o usuário pedir explicitamente “consolidado” ou “resumo estatístico”
Aí sim pode gerar o painel — **além** da classificação, ou só o painel se ele disser que não quer a tabela.
Na dúvida, se a palavra for reclassificar / classificação / ranking / tirar ausentes → **só** o formato do plugin.
