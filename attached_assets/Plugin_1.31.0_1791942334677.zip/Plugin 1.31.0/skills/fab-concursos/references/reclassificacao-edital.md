# Reclassificação no estilo da captura

Quando o usuário pedir nova classificação, PDF, cotas ou lista sem inaptos, siga este arquivo, `estilo-pdf-classificacao.md` e **obrigatoriamente** `decisao-judicial.md`.

## Arquivos de entrada

1. Lista de candidatos (nome, inscrição, MF, Port, Mat, Ing, Red, nascimento, cota, classificação original, classificação RV original se houver).
2. Lista de inaptos, ausentes ou excluídos (da etapa atual e das anteriores).
3. Edital **ou** os PDFs oficiais já fornecidos pelo usuário.

## Fonte de dados e identificação do edital (obrigatória)

- O ano, o número de vagas de ampla (N) e de reserva PP (M) **vêm exclusivamente** dos documentos que o usuário enviou.
- Leia o título do PDF, o cabeçalho e qualquer linha de resumo (ex.: "Vagas do edital: 120 ampla e 30 PP" ou "Art. 20: 104 vagas ampla + 38 pretos e pardos").
- **Não** assuma EA CPCAR 2027, nem 104/38, nem 120/30. Use o que estiver escrito nos anexos.
- Se o usuário já anexou os PDFs oficiais para gerar o Excel e o PDF, use **somente** esses arquivos.
- **Não** busque no site da FAB, não consulte notícias, não puxe edital da internet e não complete dados com fontes externas.
- Isso evita misturar números de vagas, datas ou regras de anos diferentes.
- Só consulte fonte externa para vaga ou edital se o usuário pedir ou autorizar. Exceção já autorizada: pesquise no ano do concurso quem entrou por decisão judicial e fez as etapas por causa dela, e aplique `decisao-judicial.md`.
- Se os PDFs não trouxerem o número de vagas e não houver edital, **pergunte** antes de fechar as cotas. Não invente.

## Regra de classificação

1. Tire ausentes, excluídos e incapazes da ordem. Eles vão para a aba Ausentes. Inapto e não apto entram nessa lista e saem escritos só como Incapaz.
2. **Acúmulo obrigatório de fora da ordem:** a aba `Excluidos` é cumulativa. Mantenha todos os que saíram em Provas Escritas, C.I., INSPSAU, EAP, TACF e recursos. Não apague o histórico. Ordene por etapa (Provas Escritas → C.I. → INSPSAU → EAP → TACF; recurso logo após a etapa normal). Em cada etapa: ausente, incapaz, excluído. Em cada grupo: Clas. Original crescente. Cada linha conserva a situação da etapa (ex.: Ausente C.I., Incapaz INSPSAU, Excluído nas provas escritas).
3. Ordene os presentes por MF decrescente. Empate: classificação original menor na frente.
4. As primeiras **N** posições recebem `Vaga Ampla (1-N)`. **N** é lido dos PDFs/edital fornecidos. Linha inteira laranja claro `#FFF2CC`, mesmo se a cota for Pretos e Pardos.
5. Cotista dentro dessas N ocupa vaga de ampla, não gasta reserva e não entra na lista de reserva. Linha laranja `#FFF2CC`, não verde. `Clas. RV` vazia.
5.1. Sobra de cota abre ampla remanescente. Ex.: 26 vagas PP e só 17 cotistas fora das 104 → 9 vagas sem cota, janela 105–113. Cotista dentro dessa janela (Nova Clas. 105 a 113) fica em vaga de ampla, Clas. RV vazia, e não conta nas 17. A vaga reservada vai para cotista fora da janela. Recalcule: se menos cotistas preenchem a reserva, a janela aumenta. Pare só quando nenhum cotista dentro da ampla nova tiver `Vaga Reservada PP`.
6. Depois de N, cotistas restantes preenchem `Vaga Reservada PP (n/M)`. **M** é lido dos PDFs/edital fornecidos. Linha inteira verde claro `#E2EFDA`.
7. Vaga por reversão (quando houver): não reinicie a fração. 38 PP + 8 de outras etnias revertidas = `Vaga PP por reversão (39/46)`, `(40/46)` … `(46/46)`. Proibido `(1/8)`. Numerador continua a reserva PP (igual à Clas. RV dessa vaga). Denominador = vagas originais da modalidade + vagas revertidas para ela. Cor: na classificação geral, linha inteira verde `#E2EFDA` (proibido laranja). Na lista exclusiva dos cotistas, a mesma linha laranja `#FFF2CC` (proibido verde).
8. O restante é cadastro de reserva. Ampla fora de N: `Cadastro de reserva (AC)`. Cota fora da reserva e da reversão: `Cadastro de reserva (RV)`. Sincronize com a Nova Clas. numérica: ímpar branco `#FFFFFF`, par cinza `#F2F2F2`. `Cadastro de reserva (AC)` leva essa zebra na classificação geral. `Cadastro de reserva (RV)` na classificação geral usa a Nova Clas. Na lista dos cotistas (`Reserva_PP` e bloco Reserva PP) a paridade é a da Clas. RV: ímpar branco `#FFFFFF`, par cinza `#F2F2F2`. Não use a Nova Clas. para colorir essa lista. Alvo é RV, não AC. Não deixe laranja, verde nem cor única. Não risque o texto. Nunca pinte cadastro de verde ou laranja.
9. Continue a `Clas. RV` de quem não entrou nas vagas de cota. Numere todos os cotistas que ficaram fora da ampla, na ordem da média, inclusive o cadastro de reserva. A numeração não para em M.
10. Na coluna Cota escreva `Ampla Concorrência` ou `Pretos e Pardos`.
11. Ausentes e incapazes: linha vermelho claro `#F6C9C9`, letra preta. Não use vermelho forte.
12. **Coluna de situação da etapa:** cabeçalho completo (`Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF`) conforme a etapa processada. Ver `colunas-situacao-etapa.md`. Coluna Observação permanece.
13. **Decisão judicial:** pesquise o ano do concurso, identifique quem seguiu por decisão judicial e execute o algoritmo de `decisao-judicial.md` sem reinterpretar.
    - Nova Clas. judicial = somente `*` (um caractere, zero dígitos).
    - Ordinários: 1, 2, 3… contínuos. Ex.: Ana=`23`, Bernardo=`*`, Carlos=`24`.
    - Observação = `Decisão judicial`. Situação da etapa sem a palavra judicial.
14. **Expansão:** bloco ampla = N ordinários numerados + K judiciais com `*`. Registrar em Regras/rodapé.
15. **Layout:** proibido quebrar data. Máx. 2 linhas/célula. Se apertar, corte coluna de situação.
16. **Não entregue** se o teste de sanidade de `decisao-judicial.md` falhar.
17. **PHC:** em pedido de retificação pelo Processo de Heteroidentificação Complementar, mude a cota antes de reclassificar. Não considerado preto ou pardo → `Ampla Concorrência`; não gasta reserva e não entra na lista só dos cotistas. Considerado PP → mantenha `Pretos e Pardos`. Observação: `PHC: não confirmado PP` ou `PHC: confirmado PP`. Recalcule ampla, reserva e ampla remanescente. Não altere quem o anexo não citar.
18. **Etapa real:** reclassificar o EAP depois do recurso da INSPSAU não mantém ausente falso. Se a lista do EAP diz Inapto, grave `EAP — Incapazes`. Se diz Ausente, grave `EAP — Ausentes`, mesmo que a pessoa já estivesse como ausente da INSPSAU por não constar naquela lista. Ian Porto Vasconcelos, inscrição 2060443, Clas. Original 355, é o caso: Inapto no EAP, não ausente do recurso da INSPSAU.

## Saída

Sempre Excel e PDF.

1. Excel, nesta ordem: `Classificacao_Geral`, `Reserva_PP`, `Cotistas_Ampla`, `Excluidos`, `Regras`.
2. PDF paisagem a partir desse Excel, no estilo exato de `estilo-pdf-classificacao.md`:
   - Cabeçalho `#1F3864`
   - Ampla `#FFF2CC`
   - Reserva PP `#E2EFDA`
   - Reversão: verde `#E2EFDA` só na classificação geral; laranja `#FFF2CC` na lista dos cotistas
   - Cadastro (AC): ímpar `#FFFFFF` / par `#F2F2F2` na geral. Cadastro (RV): a mesma zebra na geral e na lista dos cotistas
   - Ausentes `#F6C9C9`
   - Grade `#BFBFBF`
   - Sem tachado
   - Letras pretas

## Formato PROIBIDO na reclassificação

Quando o pedido for reclassificar / nova classificação / tirar inaptos / gerar ranking EPCAR:

**NÃO gere:**
- “Resultado Consolidado”
- painel de totais / dashboard (vagas, contagens INSPSAU/TACF na capa)
- aba ou bloco “Base_Geral” misturando classificados e eliminados na ordem das provas escritas
- PDF exportado de planilha “resumo executivo” (openpyxl/LibreOffice de consolidado)
- relatório estatístico no lugar da tabela de classificação

**Gere SOMENTE:**
1. Excel, nesta ordem: `Classificacao_Geral`, `Reserva_PP`, `Cotistas_Ampla`, `Excluidos`, `Regras`. A lista de cotistas na ampla é obrigatória.
2. PDF paisagem no estilo de `estilo-pdf-classificacao.md` + algoritmo de `decisao-judicial.md`

A capa do PDF é o **título da classificação** (ex.: “EA CPCAR 2026 — Classificação pós-TACF”) + uma linha de resumo curta (presentes, fora da ordem, N/M). Não é um painel de parâmetros editáveis.
