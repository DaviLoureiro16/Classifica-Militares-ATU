# Colunas de situação por etapa

> **ATENÇÃO (v1.22.1+) — NÃO IGNORE**
> Use cabeçalhos **COMPLETOS**: `Situação CI`, `Situação INSPSAU`, `Situação EAP`, `Situação TACF`.
> **PROIBIDO** usar só `CI`, `Inspeção`, `EAP` ou `TACF`.
> A regra antiga de “cabeçalho abreviado” foi **revogada**.

Quando houver pedido de reclassificação / alteração por causa de uma etapa eliminatória, use **cabeçalhos completos** (não abreviados):

| Etapa em processamento                         | Nome da coluna (cabeçalho) | Valores típicos              |
|------------------------------------------------|----------------------------|------------------------------|
| Pós-Concentração Intermediária (C.I. / CINTER) | `Situação CI`              | Presente, Ausente, Excluído  |
| Pós-Inspeção de Saúde                          | `Situação INSPSAU`         | Apto, Ausente, Incapaz       |
| Pós-EAP                                        | `Situação EAP`             | Apto, Ausente, Incapaz       |
| Pós-TACF / TAF                                 | `Situação TACF`            | Apto, Ausente, Incapaz       |

## Regra de inclusão

- Inclua **somente a(s) coluna(s) da etapa que está sendo processada** (e as anteriores se o usuário pedir explicitamente o histórico na tabela principal).
- Se o pedido for “pós-INSPSAU”, a coluna da etapa atual é `Situação INSPSAU`.
- Se o pedido for “pós-CI”, a coluna é `Situação CI`.
- Se o usuário pedir “mantenha as situações anteriores” ou anexar dados de etapas anteriores, pode haver mais de uma coluna de situação na tabela (ex.: `Situação CI` + `Situação INSPSAU`).
- Caso contrário, use **apenas a coluna da etapa atual**.

## O que NÃO muda

- Coluna `Observação` permanece (decisão judicial, notas de recurso, etc.).
- Aba / bloco **Ausentes** continua **cumulativo** (histórico de todas as etapas).
- Cores, Nova Clas., cotas e algoritmo de `decisao-judicial.md` permanecem iguais.
- Judicial **não** vai na coluna de Situação → vai em Observação + `*` na Nova Clas.

## Como saber a etapa

Leia o título do PDF e o pedido do usuário:

- “após a CINTER / concentração intermediária / ausentes da CI” → `Situação CI`
- “após a INSPSAU / inspeção de saúde” → `Situação INSPSAU`
- “após o EAP” → `Situação EAP`
- “após o TACF / TAF / teste físico” → `Situação TACF`

Se o usuário anexar só a lista de uma etapa, use a coluna dessa etapa. Não invente colunas de etapas sem dados nos anexos.

## Layout

Cabeçalhos longos (`Situação CI`, `Situação INSPSAU`…) exigem largura suficiente. Mantenha o texto do cabeçalho em no máximo 2 linhas e **sempre centralizado**.
