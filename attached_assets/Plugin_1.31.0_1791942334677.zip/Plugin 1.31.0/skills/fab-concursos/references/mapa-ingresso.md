# Ingresso FAB

Não invente prazo, vaga ou soldo. Prefira o edital anexo e https://www.fab.mil.br/admissao/ . Escolas: EPCAR (cadete-adolescente), AFA (oficial), EEAR (sargento), CIAAR (nível superior). Não ensine a burlar exame, cota ou documento.
