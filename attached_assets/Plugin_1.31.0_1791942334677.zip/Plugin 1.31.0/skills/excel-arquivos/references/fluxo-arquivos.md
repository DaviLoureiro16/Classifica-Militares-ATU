# Arquivos

Ao receber planilha, CSV ou PDF de lista, inspecione abas e colunas e execute o pedido. Entrega de tabela ou classificação é sempre Excel e PDF, no estilo de `estilo-pdf-classificacao.md` quando for ranking da EPCAR.
