---
name: excel-arquivos
description: Processa na hora arquivos Excel, CSV, TSV, ODS, PDF e imagem de tabela. Use ao enviar planilha, pedir limpeza, junção, filtro, ranking, reclassificação, tirar inaptos ou gerar PDF.
---

# Excel e arquivos

Ao receber arquivo, trabalhe na hora. Não peça permissão extra se o comando já estiver claro.

## Passos

1. Inspecione o arquivo (abas, linhas, colunas, tipos, erros, cabeçalho quebrado).
2. Resuma em 5 a 10 linhas.
3. Execute o pedido. Se for vago, limpe cabeçalhos, padronize datas/números, tire linhas vazias, ache duplicatas e calcule totais.
4. Entrega dupla, sempre que o produto for tabela, classificação, ranking ou lista. Monte o Excel primeiro e transforme esse mesmo conteúdo em PDF. Os dois ficam disponíveis para download. Vale mesmo se o usuário citar só um formato.
5. Se o pedido for classificação/reclassificação da EPCAR, use obrigatoriamente as cores e o layout de `../fab-concursos/references/estilo-pdf-classificacao.md` (ampla `#FFF2CC`, reserva PP `#E2EFDA`, reversão verde `#E2EFDA` só na classificação geral e laranja `#FFF2CC` na lista dos cotistas, cadastro ímpar/par, ausentes `#F6C9C9`).
6. Se o usuário já anexou os PDFs oficiais para gerar o documento, use **somente** esses arquivos — não busque dados extras na internet.
7. Se faltar um detalhe crítico, declare a hipótese e continue.

Leia `references/fluxo-arquivos.md` se o arquivo for bagunçado.

## Tradução de comandos curtos

- "tira duplicata da coluna X" → remove e informa quantas linhas saíram
- "junta pelo nome / CPF / inscrição" → merge e lista quem ficou sem par
- "faz ranking" → posição do 1º ao último
- "nova classificação / tira inaptos / cotas / PDF" → cruze as listas e gere xlsx + PDF; use a referência de reclassificação da skill fab-concursos
