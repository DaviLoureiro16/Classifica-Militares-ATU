---
description: Consulta concurso, edital ou notícia da FAB e, se houver lista, reclassifica. Se a reversão da classificação geral estiver laranja, conserta para verde.
---

Ative a skill fab-concursos. Use o edital anexo. Não invente vaga nem prazo.

Se a classificação geral tiver qualquer linha com `reversão` laranja ou amarela, isso bloqueia a entrega. Execute `commands/reclassificar.md`: verde `#E2EFDA` na geral, laranja `#FFF2CC` só na lista exclusiva dos cotistas, e reentregue Excel e PDF. Não encerre só dizendo que a regra mudou.

Se `Cadastro de reserva (RV)` estiver branco/cinza só na classificação geral, ou sem alternância na lista dos cotistas, execute `commands/reclassificar.md`: ímpar `#FFFFFF` e par `#F2F2F2` pela Nova Clas. também na aba `Reserva_PP` e no bloco de cotistas. O alvo é RV, não AC. Reentregue Excel e PDF.

Se houver lista para reclassificar, execute `commands/listas.md`: sempre as quatro listas, nesta ordem — classificação geral, só cotistas, cotistas nas vagas da ampla, excluídos acumulados (ausentes, incapazes e excluídos). Excel e PDF no estilo da 1.25.0.
