---
description: Sempre gera, nesta ordem, classificação geral, lista só dos cotistas, cotistas nas vagas da ampla e excluídos acumulados. Mantém o estilo da 1.25.0. Reentrega Excel e PDF.
---

Ative excel-arquivos e fab-concursos. Leia `estilo-pdf-classificacao.md` e `reclassificacao-edital.md`.

Entregue Excel e PDF. Não encerre só descrevendo a regra.

## Ordem obrigatória — sempre as quatro

Excel, abas nesta ordem:

1. `Classificacao_Geral` — classificação geral
2. `Reserva_PP` — lista só dos cotistas (fora da ampla: reservada, reversão e cadastro RV)
3. `Cotistas_Ampla` — cotistas que ocuparam vaga da ampla
4. `Excluidos` — ausentes, incapazes e excluídos, acumulativo
5. `Regras` — por último, só apoio

PDF, blocos na mesma ordem, cada um com título próprio. Proibido pular a lista 3 ou a lista 4. Proibido juntar excluídos na classificação geral.

### 1. Classificação geral
Ampla, cotistas na ampla, reserva, reversão e cadastros. Reversão verde `#E2EFDA`. Fração da reversão continua a reserva: `(39/46)`, não `(1/8)`. Cadastro pela Nova Clas.: ímpar `#FFFFFF`, par `#F2F2F2`.

### 2. Lista só dos cotistas
Quem não entrou na ampla. Clas. RV contínua. Reversão laranja `#FFF2CC`. `Cadastro de reserva (RV)`: ímpar/par pela Clas. RV, não pela Nova Clas.

### 3. Cotistas nas vagas da ampla
Só cotista com vaga de ampla, inclusive quem caiu na ampla remanescente (janela 105–113 ou a janela recalculada). Linha laranja `#FFF2CC`. Clas. RV vazia. Esse cotista não aparece na lista só dos cotistas e não gasta reserva.


### 4. Excluídos acumulativos
Ausentes, incapazes e excluídos de todas as etapas. Não apague o histórico. Fundo `#F6C9C9`, letra preta. Situação: `Ausente`, `Incapaz` ou `Excluído`. Motivo e etapa em Observação.

Ordem obrigatória da aba `Excluidos` e do bloco 4 do PDF. Não misture etapas nem tipos.

1. Separe pela etapa em que saiu, nesta ordem: Provas Escritas, C.I., INSPSAU, EAP, TACF.
2. Se houver recurso de uma etapa, o bloco do recurso vem logo depois do bloco normal dessa etapa. Ex.: INSPSAU, depois recurso da INSPSAU, depois EAP.
3. Dentro de cada etapa (e de cada recurso): primeiro ausentes, depois incapazes, depois excluídos.
4. Dentro de cada um desses grupos, ordene pela classificação original, da menor para a maior.
5. Título de bloco visível, por exemplo `Provas Escritas — Ausentes`.
6. A etapa do bloco é a etapa em que a pessoa saiu de fato, lida na lista oficial daquela etapa. Não deixe Inapto do EAP como Ausente da INSPSAU só porque a INSPSAU foi processada antes. Ex.: Ian Porto Vasconcelos, inscrição 2060443, Clas. Original 355, Inapto no EAP → `EAP — Incapazes`.



Estilo 1.25.0 permanece: cabeçalhos centralizados, coluna `Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF`, sem tachado, sem dashboard.

### PHC — retificação de cota
Se o pedido for retificação pelo Processo de Heteroidentificação Complementar:
- não considerado PP → cota `Ampla Concorrência`; sai da reserva e da lista só dos cotistas;
- considerado PP → cota `Pretos e Pardos` permanece.
Não invente resultado. Recalcule as quatro listas e reentregue Excel e PDF.
