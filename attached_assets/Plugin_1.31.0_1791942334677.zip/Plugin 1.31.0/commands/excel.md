---
description: Processa na hora o arquivo ou monta a planilha pedida. Se a classificação geral tiver reversão laranja, conserta para verde.
---

Ative a skill excel-arquivos. Inspecione o anexo. Se o produto for tabela, classificação ou lista, entregue Excel e PDF. "Monte um Excel e transforme em PDF" já pede os dois.

Se a classificação geral tiver `Vaga PP por reversão` em laranja ou amarelo, isso é erro. Execute a correção de `commands/reclassificar.md`: verde `#E2EFDA` só na classificação geral; na lista dos cotistas a reversão continua `#FFF2CC`. Reentregue os dois arquivos.
