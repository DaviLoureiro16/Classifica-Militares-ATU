---
description: Nova classificação. BLOQUEIO: reversão na geral é verde #E2EFDA e a fração continua (39/46, não 1/8). Laranja só na lista dos cotistas. Nessa lista, cadastro RV ímpar/par segue a Clas. RV.
---

Ative excel-arquivos e fab-concursos.

Leia **nesta ordem**:
1. skills/fab-concursos/references/formato-proibido.md   ← o que NÃO entregar
2. skills/fab-concursos/references/etapas-eliminatorias.md
3. skills/fab-concursos/references/regras-edital-classificacao.md
4. skills/fab-concursos/references/decisao-judicial.md   ← algoritmo judicial
5. skills/fab-concursos/references/colunas-situacao-etapa.md  ← colunas de etapa com cabeçalho completo (Situação CI / Situação INSPSAU / Situação EAP / Situação TACF)
6. skills/fab-concursos/references/estilo-pdf-classificacao.md
7. skills/fab-concursos/references/reclassificacao-edital.md

Identifique etapa e ano pelo título do PDF. Use os anexos para N e M. Não assuma 2027. Pode pesquisar, no ano do concurso, quem entrou por decisão judicial e fez as etapas por causa dela. Aplique o algoritmo do `*` a esses candidatos.

### ERRO A CONSERTAR — reversão laranja na classificação geral (ainda acontecendo)

O Claude continua pintando cotista por reversão de laranja na classificação geral. Isso está errado. Laranja na reversão só na lista exclusiva dos cotistas.

Ao gerar ou ao receber classificação já pronta:

1. Ache toda linha cuja Situação da Vaga contenha `reversão` (PP, indígenas, quilombolas).
2. Na aba `Classificacao_Geral` e no bloco geral do PDF, pinte a **linha inteira** de verde `#E2EFDA`. Proibido `#FFF2CC`, amarelo, branco ou cinza nessas linhas.
3. Na aba `Reserva_PP` e no bloco exclusivo dos cotistas, a mesma linha fica laranja `#FFF2CC`. Proibido verde aí.
4. Não copie a cor da lista dos cotistas para a geral. As duas listas divergem de propósito.
5. Não mexa no texto, na ordem, na Clas. RV nem nas notas só por causa da cor.
6. Reescreva a fração. Não entregue `(1/8)`. Se 38 PP e 8 vagas de outras etnias revertem, o texto é `Vaga PP por reversão (39/46)`, `(40/46)` … `(46/46)`. Numerador continua a reserva; denominador = PP + revertidas.
7. Reentregue Excel e PDF. Dizer que a regra foi atualizada, sem os dois arquivos, não cumpre o comando.

### ERRO A CONSERTAR — zebra do cadastro RV só na classificação geral

Erro já cometido: ímpar branco `#FFFFFF` e par cinza `#F2F2F2` saíram só na classificação geral. Na lista dos cotistas, quem é `Cadastro de reserva (RV)` ficou sem essa alternância. O alvo dessa lista é RV, não AC.

Ao receber classificação, Excel ou PDF já gerado, ou o pedido de corrigir a cor do cadastro:

1. Ache toda linha cuja Situação da Vaga seja `Cadastro de reserva (RV)`.
2. Na classificação geral, pinte pela Nova Clas.: ímpar `#FFFFFF`, par `#F2F2F2`.
3. Na lista dos cotistas (`Reserva_PP` e bloco de cotas), pinte pela Clas. RV, não pela Nova Clas.: Clas. RV ímpar branca, par cinza. Ex.: 47 branca, 48 cinza.
4. Não pinte `Cadastro de reserva (RV)` de laranja nem de verde na lista dos cotistas. Não troque o alvo para AC.
5. `Cadastro de reserva (AC)` continua com a mesma zebra na classificação geral.
6. Não mexa no texto, na ordem, na Clas. RV nem nas notas só por causa da cor.
7. Reentregue Excel e PDF. Sem os dois arquivos com a zebra do RV também na lista dos cotistas, o comando não foi cumprido.

### PROIBIDO neste comando
- “Resultado Consolidado”
- painel/dashboard de totais como produto principal
- “Base_Geral” misturando classificados e eliminados
- relatório estatístico no lugar da tabela de classificação
- Entregar a classificação geral com qualquer `reversão` laranja, amarela ou sem o verde `#E2EFDA`
- Pintar reversão de verde na lista dos cotistas
- Deixar `Cadastro de reserva (RV)` sem zebra (ímpar branco / par cinza) na lista dos cotistas
- Aplicar a zebra do RV só na classificação geral
- Tratar o alvo da lista dos cotistas como AC em vez de RV

### OBRIGATÓRIO
- Excel, nesta ordem: `Classificacao_Geral` | `Reserva_PP` | `Cotistas_Ampla` | `Excluidos` | `Regras`
- PDF na mesma ordem: geral; só cotistas; cotistas na ampla; excluídos acumulados (ausentes, incapazes e excluídos)
- Siga também `commands/listas.md`
- PDF paisagem no estilo do plugin (não export de consolidado LibreOffice)
- Título: `EA CPCAR AAAA — Classificação pós-XXXX` + 1 linha de resumo
- Se o anexo já for uma classificação, corrija a cor da reversão e entregue os arquivos de novo

### Cores
Ampla `#FFF2CC` · Reserva PP `#E2EFDA` · Reversão verde `#E2EFDA` só na classificação geral (na lista dos cotistas, reversão `#FFF2CC`) · Cadastro (AC) ímpar `#FFFFFF` / par `#F2F2F2` na geral · Cadastro (RV) a mesma zebra na geral **e** na lista dos cotistas · Ausentes `#F6C9C9` · Cabeçalho `#1F3864` · Sem tachado

### Decisão judicial — algoritmo
```
numero = 1
para cada candidato ordenado por MF:
  se judicial:
    Nova_Clas = "*"
    Observacao = "Decisão judicial"
  senão:
    Nova_Clas = numero
    numero = numero + 1
```
Ex.: Ana=`23`, Bernardo=`*`, Carlos=`24`.  
Proibido: `28*`, número + “dec. judicial” na Situação.  
Bloco ampla = N ordinários + K com `*`.

### Coluna de situação (cabeçalho completo)
| Etapa | Cabeçalho |
|-------|-----------|
| Pós-CI / CINTER | `Situação CI` |
| Pós-INSPSAU | `Situação INSPSAU` |
| Pós-EAP | `Situação EAP` |
| Pós-TACF | `Situação TACF` |
Use a coluna da etapa processada. Se o usuário pedir histórico, pode haver mais de uma.

### Layout
- Proibido quebrar data. Máx. 2 linhas/célula.
- **Cabeçalhos (títulos) TODOS centralizados** — inclusive “Nome”. Nunca left no header de Nome.
- Corpo: Nome left; resto center.
- Coluna de etapa = `Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF` (nunca só `CI` ou `Inspeção`).

### Teste de sanidade — se falhar, NÃO entregue
1. Formato é consolidado/Base_Geral/dashboard? → refazer no formato do plugin
2. Judicial com número ou `28*`? → refazer
3. “judicial” na Situação da etapa? → refazer
4. Data partida? → refazer
5. Numeração dos ordinários com buraco por judicial? → refazer
6. Na classificação geral, alguma linha com `reversão` está laranja, amarela ou sem o verde `#E2EFDA`? → não entregue; pinte e reentregue Excel e PDF
7. Na lista dos cotistas, alguma reversão ficou verde? → voltar para laranja `#FFF2CC`
8. **Clas. RV preenchida em linha de Vaga Ampla?** → esvaziar e refazer
9. **Cabeçalho “Nome” (ou qualquer título) não está centralizado?** → refazer
10. Coluna de etapa ainda abreviada (`CI` / `Inspeção`) em vez de `Situação CI` / `Situação INSPSAU`? → refazer
11. Na lista dos cotistas, `Cadastro de reserva (RV)` sem branco/cinza pela Clas. RV? → refazer e reentregar Excel e PDF
12. Zebra da lista dos cotistas calculada pela Nova Clas. em vez da Clas. RV? → refazer
13. Reversão escrita `(1/8)` em vez de continuar a reserva, como `(39/46)`? → refazer

14. Faltou `Cotistas_Ampla` ou `Excluidos`, ou a ordem não é geral → só cotistas → cotistas na ampla → excluídos? → refazer

Só entregue depois de passar no teste. Excluídos cumulativos.
