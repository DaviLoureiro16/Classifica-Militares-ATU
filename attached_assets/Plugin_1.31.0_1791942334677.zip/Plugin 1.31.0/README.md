# Excel + FAB Assistente

Plugin Claude (não é pacote de skill única).

Instale o zip em Claude Code como plugin. O manifesto está em `.claude-plugin/plugin.json`.

Versão **1.31.0**. Entrega Excel e PDF. O estilo fica no plugin e não exige o PDF de modelo a cada pedido.

### Cores oficiais (padronizadas)

| Situação | Onde | Cor | Hex |
|----------|------|-----|-----|
| Vaga Ampla | Geral e lista de cotistas | Laranja claro | `#FFF2CC` |
| Vaga Reservada PP | Geral e lista de cotistas | Verde claro | `#E2EFDA` |
| Vaga por reversão | Só classificação geral | Verde claro | `#E2EFDA` |
| Vaga por reversão | Lista dos cotistas | Laranja claro | `#FFF2CC` |
| Cadastro de reserva (AC), ímpar | Classificação geral | Branco | `#FFFFFF` |
| Cadastro de reserva (AC), par | Classificação geral | Cinza claro | `#F2F2F2` |
| Cadastro de reserva (RV), ímpar | Geral e lista dos cotistas | Branco | `#FFFFFF` |
| Cadastro de reserva (RV), par | Geral e lista dos cotistas | Cinza claro | `#F2F2F2` |
| Ausentes / Incapazes | Qualquer lista | Vermelho claro | `#F6C9C9` |
| Cabeçalho da tabela | Qualquer lista | Azul-marinho | `#1F3864` |

Não risca cadastro de reserva. Letras sempre pretas. Cotista por reversão fica verde `#E2EFDA` na classificação geral. Laranja `#FFF2CC` na reversão só na lista exclusiva dos cotistas. Entregar a geral com reversão laranja é erro. A zebra do `Cadastro de reserva (RV)` na lista dos cotistas segue a Clas. RV (ímpar branco, par cinza), não a Nova Clas. A reversão não reinicia: `(39/46)`, não `(1/8)`.

### Regras importantes

- **Edital e vagas vêm dos anexos:** o Claude lê o ano, N (ampla) e M (PP) exclusivamente dos PDFs/edital que o usuário enviou. Não assume 2027 nem qualquer outro ano.
- **Fonte de dados:** quando o usuário já fornece os PDFs oficiais, usa **somente** esses arquivos. Não busca informações extras no site da FAB.
- **Aba Ausentes cumulativa** entre C.I., INSPSAU, EAP e TACF.
- Preserva colunas extras (Situação INSPSAU, Situação TACF, Observação etc.).

### Histórico

- **1.31.0:** pode pesquisar no ano do concurso quem entrou por decisão judicial e fez as etapas por causa dela. A esses candidatos, aplique a regra do `*` em `decisao-judicial.md`.
- **1.30.0:** a etapa real da saída manda. Inapto no EAP não fica como ausente da INSPSAU só porque a INSPSAU foi atualizada antes. Ian Porto Vasconcelos, 2060443, vai para `EAP — Incapazes`.
- **1.29.0:** retificação pelo PHC: não considerado PP passa a `Ampla Concorrência`; considerado PP mantém `Pretos e Pardos`. Recalcular a classificação.
- **1.28.0:** aba `Excluidos` separada por etapa (Provas Escritas, C.I., INSPSAU, EAP, TACF; recurso depois da etapa) e, em cada etapa, ausente, incapaz, excluído, pela classificação original.
- **1.27.0:** cotista dentro da ampla remanescente (ex.: janela 105–113 aberta por 9 sobras de PP) não gasta reserva. A vaga de cota fica para quem está fora dessa ampla nova. Recalcular até estabilizar.
- **1.26.0:** comando `/listas` sempre gera, nesta ordem, classificação geral, lista só dos cotistas, cotistas nas vagas da ampla e excluídos acumulados (ausentes, incapazes e excluídos). Estilo da 1.25.0.
- **1.25.0:** reversão continua a reserva (`Vaga PP por reversão (39/46)`, não `(1/8)`). Na lista dos cotistas, cadastro RV ímpar/par usa a Clas. RV, não a Nova Clas.
- **1.24.0:** bloqueio de entrega: reversão na classificação geral é verde `#E2EFDA`. Laranja `#FFF2CC` na reversão só na lista exclusiva dos cotistas. Geral laranja não pode ser entregue.
- **1.23.1:** correção: na lista dos cotistas a zebra (ímpar `#FFFFFF`, par `#F2F2F2`) é do `Cadastro de reserva (RV)`, não do AC. AC continua com a mesma zebra só na classificação geral.
- **1.23.0:** zebra do cadastro também na lista dos cotistas (redigida por engano como AC; corrigida em 1.23.1 para RV).
- **1.22.2:** colunas de situação com cabeçalho completo (`Situação CI` / `Situação INSPSAU` / `Situação EAP` / `Situação TACF`); todos os títulos de coluna centralizados (incluindo Nome).
- **1.20.0:** o comando `/reclassificar` conserta o erro de reversão laranja na classificação geral: pinta `#E2EFDA` e reentrega Excel e PDF. Na lista dos cotistas, reversão continua `#FFF2CC`.
- **1.19.0:** na classificação geral, quem pegou reserva por reversão fica verde `#E2EFDA` (o mesmo da vaga reservada). Na lista dos cotistas, reversão continua laranja `#FFF2CC`.
- **1.18.0:** coluna de situação única e abreviada por etapa (`CI`/`Inspeção`/`EAP`/`TACF`), substituindo a anterior.
- **1.17.0:** proíbe Resultado Consolidado / Base_Geral / dashboard na reclassificação; saída só no estilo do plugin.
- **1.16.0:** algoritmo obrigatório de decisão judicial (`decisao-judicial.md`); teste de sanidade bloqueia entrega se judicial numerado.
- **1.15.0:** reforço anti-erro: judicial só `*` sem número; layout sem quebra de data; checklist de entrega obrigatório.
- **1.14.1:** decisão judicial = somente `*` (sem número); numeração continua só entre não-judiciais; bloco de ampla = N numerados + K judiciais.
- **1.14.0:** colunas de situação por etapa; decisão judicial com `*` e expansão de vagas; larguras de coluna confortáveis.
- **1.13.0:** remove preferência por EA CPCAR 2027; N e M são lidos só dos documentos enviados; reforço da regra de fonte de dados.
- **1.12.0:** cores unificadas (`#FFF2CC` / `#E2EFDA`); regra de não buscar dados externos quando os PDFs já foram fornecidos.
- **1.11.0:** aba Ausentes cumulativa entre C.I., INSPSAU, EAP e TACF.
